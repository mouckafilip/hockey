-- Adminer 5.3.0 MySQL 8.4.3 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `goly`;
CREATE TABLE `goly` (
  `id` int NOT NULL AUTO_INCREMENT,
  `zapas_id` int NOT NULL,
  `hrac_id` int NOT NULL,
  `minuta` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `zapas_id` (`zapas_id`),
  KEY `hrac_id` (`hrac_id`),
  CONSTRAINT `goly_ibfk_1` FOREIGN KEY (`zapas_id`) REFERENCES `tymy` (`id`) ON DELETE CASCADE,
  CONSTRAINT `goly_ibfk_2` FOREIGN KEY (`hrac_id`) REFERENCES `tymy` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `hraci`;
CREATE TABLE `hraci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tym_id` int NOT NULL,
  `cislo` int NOT NULL,
  `jmeno` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pozice` enum('brankar','obrance','utocnik') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `klub` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tym_id` (`tym_id`),
  CONSTRAINT `hraci_ibfk_1` FOREIGN KEY (`tym_id`) REFERENCES `tymy` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `tymy`;
CREATE TABLE `tymy` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kod` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nazev` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `skupina` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `trener` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vlajka_emoji` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kod` (`kod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tymy` (`id`, `kod`, `nazev`, `skupina`, `trener`, `vlajka_emoji`) VALUES
(6,	'CES',	'esef',	'A',	'sef',	'ctz'),
(7,	'ESE',	'esf',	'A',	'efs',	'sef');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `users` (`id`, `username`, `password`, `admin`) VALUES
(1,	'admin',	'$2y$10$b.MKL6hF7uvB3zLn9YHLHuptz2fr/AUWBd30IWkQ.KTJWytIZXtqK',	1),
(2,	'user',	'$2y$10$wjYEOEAuQtt7fz6m0twUi.vDmjibxyZRdm97n1j/dkY8WviEvsZ.O',	0);

DROP TABLE IF EXISTS `zapasy`;
CREATE TABLE `zapasy` (
  `id` int NOT NULL AUTO_INCREMENT,
  `datum` datetime NOT NULL,
  `domaci_id` int NOT NULL,
  `hoste_id` int NOT NULL,
  `skore_domaci` int DEFAULT NULL,
  `skore_hoste` int DEFAULT NULL,
  `prodlouzeni` tinyint(1) DEFAULT '0',
  `faze` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'skupina',
  `arena` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `domaci_id` (`domaci_id`),
  KEY `hoste_id` (`hoste_id`),
  CONSTRAINT `zapasy_ibfk_1` FOREIGN KEY (`domaci_id`) REFERENCES `tymy` (`id`),
  CONSTRAINT `zapasy_ibfk_2` FOREIGN KEY (`hoste_id`) REFERENCES `tymy` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2026-05-28 11:17:37 UTC
